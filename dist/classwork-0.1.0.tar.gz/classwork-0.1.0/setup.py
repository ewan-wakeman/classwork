# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['classwork']

package_data = \
{'': ['*']}

install_requires = \
['ipykernel>=6.6.1,<7.0.0',
 'jupyter>=1.0.0,<2.0.0',
 'logzero>=1.7.0,<2.0.0',
 'pathlib>=1.0.1,<2.0.0']

setup_kwargs = {
    'name': 'classwork',
    'version': '0.1.0',
    'description': 'A dummy package for playing with metclasses, abcs, codecs, etc...',
    'long_description': None,
    'author': 'Ewan Wakeman',
    'author_email': 'ewan.wakeman@nhs.net',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
